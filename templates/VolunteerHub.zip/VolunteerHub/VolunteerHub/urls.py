from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    # Административен панел
    path('admin/', admin.site.urls),

    # Акаунти: login, logout, register, profile и т.н.
    path('accounts/', include(('accounts.urls', 'accounts'), namespace='accounts')),

    # Събития — главен път
    path('', include(('events.urls', 'events'), namespace='events')),

    # Кандидатури
    path('applications/', include(('applications.urls', 'applications'), namespace='applications')),

    # Организации
    path('organizations/', include(('organizations.urls', 'organizations'), namespace='organizations')),

    # Локации
    path('locations/', include(('locations.urls', 'locations'), namespace='locations')),

    # Контакт
    path('contact/', include(('core.urls', 'contact'), namespace='contact')),
]
