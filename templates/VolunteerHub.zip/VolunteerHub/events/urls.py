from django.urls import path
from .views import (
    EventListView, EventDetailView,
    EventCreateView, EventUpdateView, DashboardView, EventDeleteView
)
app_name = 'events'
urlpatterns = [
    path('', EventListView.as_view(), name='event-list'),
    path('event/<int:pk>/', EventDetailView.as_view(), name='event-detail'),
    path('event/create/', EventCreateView.as_view(), name='event-create'),
    path('event/<int:pk>/edit/', EventUpdateView.as_view(), name='event-update'),
    path('dashboard/', DashboardView.as_view(), name='dashboard'),
    path('event/<int:pk>/delete/', EventDeleteView.as_view(), name='event-delete'),


]
